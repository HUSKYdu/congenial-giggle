from sklearn import svm
import pylab as pl  # 绘图功能
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
import random
import math
import time
from sklearn.pipeline import Pipeline
df = pd.read_csv('dataset.csv', header=None)
data = []
for i in df.index:
    data.append(list(df.values[i]))
dataset = data
labelset = pd.read_csv('labelset.csv')
labelset = labelset['label']

'''
4th method to train parameters

'''
#############################################################################################################
# compute the weight gradient
def Weight_Gredient(e,x,centre,sigma):
    N=len(e)
    total=0
    xlen=len(x[0])
    x1=[]
    x2=0

    for i in range(0,N):
        for j in range(0, xlen):
            m = x[i][j] - centre[j]
            x1.append((m ** 2))
        x2 = sum(x1)
        total=total+(e[i]*(-math.exp((x2/(2*(sigma**2))))))
    return total


#compute center gradient
def Centre_Location_Gredient(w,e,x,centre,sigma):
    N=len(e)
    total=[]
    x1=[]
    x2=0
    x3=[]
    xlen = len(x[0])
    for i in range(0, N):
        x1=[]
        for j in range(0, xlen):
            m = x[i][j] - centre[j]
            x1.append((m ** 2))
        x2 = sum(x1)
        x3=[]
        for j in range(0, xlen):
            s = x[i][j] - centre[j]
            x3.append(s)
        new_list = [x / (sigma**2) for x in x3]
        mid=[x * (e[i] * (-math.exp((x2 / (2 * (sigma ** 2)))))) for x in new_list]
        total.append(mid)
    totallen=len(total)
    newcentre=[]
    sg=0
    for u in range(0,xlen):
        sg=0
        for t in range(0,totallen):
            sg=sg+total[t][u]
        newcentre.append(sg)
    newcentre=[x*w for x in newcentre]
    return newcentre

#following six functions is define some list computation process to help us simpal code
def List_add(x1,x2):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]+x2[i]
        xk.append(m)
    return xk
def List_sub(x1,x2):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]-x2[i]
        xk.append(m)
    return xk
def List_mul(x1,x2):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]*x2[i]
        xk.append(m)
    return xk
def List_div(x1,x2):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]/x2[i]
        xk.append(m)
    return xk
def List_square(x1):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]**2
        xk.append(m)
    xsum=sum(xk)
    return xsum
def List_mul_num(x1,num):
    xlen=len(x1)
    xk=[]
    for i in range(0,xlen):
        m=x1[i]*num
        xk.append(m)
    return xk


#compute width gradient
def Width_Gredient(w,e,x,centre,sigma):
    N=len(e)
    if isinstance(centre,float):
        m=1
    else:
        m=len(centre)
    msum=0
    esum=0
    middlelist=[]
    if m==1:
        for k in range(0,N):
            for j in range(0,m):
                middle=w*math.exp(-(List_square((List_sub((x[k]),centre))))/(2*(sigma**2)))
                msum=middle*((List_square(List_sub(x[k],centre)))/(sigma**3))
            esum=e[k]*msum
            middlelist.append(esum)
        newwidth=sum(middlelist)
    else:
        for k in range(0,N):
            for j in range(0,m):
                middle=w[j]*math.exp(-(List_square(List_sub(x[k],centre[j])))/(2*(sigma**2)))
                msum=middle*((List_square(List_sub(x[k],centre[j])))/(sigma**3))
            esum=e[k]*msum
            middlelist.append(esum)
        newwidth=sum(middlelist)

    return newwidth




def Loss_Function(truelabel,predictlabel):
    llen=len(truelabel)
    errorlist = []
    for i in range(0,llen):
        if predictlabel[i]>1:
            predictlabel[i]=1
        elif predictlabel[i]<-1:
            predictlabel[i] = -1
    for j in range(0,llen):
        if predictlabel[j]>=0:
            k=1-predictlabel[j]
        else:
            k = -1 - predictlabel[j]
        errorlist.append(k)
    return errorlist


#random select train and test data in trainingdata(330 samples)
def Data_select(number_of_train,dataset,labelset):
    train_num=[]
    test_num=[]
    train_set=[]
    test_set=[]
    train_label=[]
    test_label=[]
    datalen=len(dataset)
    flag=0
    while flag!=number_of_train:
        h = random.randint(0, datalen - 1)
        if train_num.count(h) == 0:
            train_num.append(h)
            flag=flag+1
        else:
            continue
    for i in range(0,datalen):
        if train_num.count(i) == 0:
            test_num.append(i)
    trainlen=len(train_num)
    testlen = len(test_num)
    for j in range(0,trainlen):
        m=train_num[j]
        train_set.append(dataset[m])
        train_label.append(labelset[m])
    for k in range(0,testlen):
        m=test_num[k]
        test_set.append(dataset[m])
        test_label.append(labelset[m])
    return train_set,train_label,test_set,test_label

#random select centers as initial centers
def Centre_Random_Selection(training_set,number_of_centre):
    setlen=len(training_set)
    selected_num=[]
    selected_data=[]
    distance1=[]
    distance2=0
    dmax=0
    i=0
    while i!=number_of_centre:
        h=random.randint(0,setlen-1)
        if selected_num.count(h)==0:
            selected_num.append(h)
            i=i+1
        else:
            continue
    for m in range(0,number_of_centre):
        k=selected_num[m]
        s=training_set[k]
        selected_data.append(s)

    for i in range(0,number_of_centre):
        for j in range(i,number_of_centre):
            distance=list(map(lambda x: x[0] - x[1], zip(selected_data[i], selected_data[j])))
            distance1 = []
            dislen=len(distance)

            for m in range(0,dislen):
                distance1.append(distance[m]** 2)
            dis1len = len(distance1)
            for n in range(0,dis1len):
                distance2 = distance2 + distance1[n]
            distance2 = distance2 ** 0.5
            if distance2>dmax:
                dmax=distance2
    sigma=(dmax/((2*number_of_centre)**0.5))
    return selected_data,sigma
def GF(di, sigma):
    result = math.exp(-((di ** 2) / (2 * (sigma ** 2))))
    return result
def Neuron(centre, sigma, x):
    # distance=x-centre
    distance = list(map(lambda x: x[0] - x[1], zip(x, centre)))
    distance1 = []
    distance2 = 0
    dislen = len(distance)
    for i in range(0, dislen):
        m = distance[i] ** 2
        distance1.append(m)
    dis1len = len(distance1)
    for j in range(0, dis1len):
        distance2 = distance2 + distance1[j]
    distance2 = distance2 ** 0.5
    di = distance2
    oi = GF(di, sigma)
    return oi
def Predict(centre,w,test_set,sigma):
    tlen=len(test_set)
    clen=len(centre)
    result=0
    predictlabel=[]
    for i in range(0,tlen):
        for j in range(0,clen):
            result=result+w[j]*Neuron(centre[j],sigma,test_set[i])

        predictlabel.append(result)
    return predictlabel
def Accuracy_Rate(predict_label,real_label):
    pllen=len(predict_label)
    rllen=len(real_label)
    true_point=0
    for j in range(0,pllen):
        if predict_label[j]>0:
            predict_label[j]=1
        else:
            predict_label[j]=-1

    for i in range(0,pllen):
        if predict_label[i]==real_label[i]:
            true_point=true_point+1
    accuracy_rate=(true_point/rllen)
    return accuracy_rate

#fit function, epoch is times we want to train ,eta1 to eta3 is learning rate of weight, center and width
def Fit(dataset,labelset,number_of_train,epoch,eta1,eta2,eta3,num_centre):
    centre,k=Centre_Random_Selection(dataset, num_centre)
    w=[]
    for s in range(0,num_centre):
        w.append(0.3)
    sigma=5
    print("Initial Centre is:",centre)
    print("Initial weight is:", w)
    print("Initial sigma is:", sigma)
    accuracylist=[]
    nw=[]
    newcentre=[]
    epochtimes=[]
    accuracy=[]

    for i in range(0,epoch):
        train_set,train_label,test_set,test_label=Data_select(number_of_train, dataset, labelset)
        print('epoch:', i + 1, '      training........')
        predictlabel=Predict(centre, w, train_set, sigma)
        el=Loss_Function(train_label,predictlabel)

        for j in range(0,num_centre):
            newweight=w[j]-eta1*Weight_Gredient(el, train_set, centre[j], sigma)
            nw.append(newweight)
        for s in range(0,num_centre):
            nc=List_sub(centre[s],List_mul_num(Centre_Location_Gredient(w[j],el, train_set, centre[s], sigma),eta2))
            newcentre.append(nc)
        newwidth=sigma+eta3*Width_Gredient(w,el,train_set,centre,sigma)

        w=nw
        centre=newcentre
        sigma=newwidth
        time_start=time.time()

        testlabel=Predict(centre, w, test_set, sigma)
        time_end=time.time()
        print('time cost',time_end-time_start,'s')

        ac=Accuracy_Rate(testlabel,test_label)
        print('epoch:',i+1,'      Accuracy Rate is :',ac)

        epochtimes.append(i)
        accuracylist.append(ac)
    plt.plot(epochtimes,accuracylist)
    plt.show()
    print(epochtimes,accuracylist)


Fit(dataset,labelset,231,50,0.001,0.001,0.001,40)





'''
truelabel=[1,-1,1]
predictlabel=[0.9,-0.8,0.8]
esum=Loss_Function(truelabel,predictlabel)
print(esum)
e=[0.09,0.01]
x=[[0.67,0,0.3],[0.73,0.5,0.2]]
centre=[0.02,0.45,0.13]
w=0.000001
xm=Width_Gredient(w,e,x,centre,0.5)
print(xm)
'''


