import numpy as np
import pandas as pd
import random
import math
import time
'''
this document is mothod 1 to select center for RBF,
I define some basic fucntion such as Gaussian Function, random select center function and others

'''
#load data
df = pd.read_csv('dataset.csv', header=None)
data = []
for i in df.index:
    data.append(list(df.values[i]))
dataset = data
labelset = pd.read_csv('labelset.csv')
labelset = labelset['label']
hc = pd.read_csv('testset.csv', header=None)
test = []
for i in hc.index:
    test.append(list(hc.values[i]))
testset = test
#dataset is testingset which has currect label
#labelset
#testset has 21 samples


#gaussian function
def GF(di,sigma):
    result=math.exp(-((di**2)/(2*(sigma**2))))
    return result

#random select centers
def Centre_Random_Selection(training_set,number_of_centre):
    setlen=len(training_set)
    selected_num=[]
    selected_data=[]
    distance1=[]
    distance2=0
    dmax=0
    i=0
    while i!=number_of_centre:
        h=random.randint(0,setlen-1)
        if selected_num.count(h)==0:
            selected_num.append(h)
            i=i+1
        else:
            continue
    for m in range(0,number_of_centre):
        k=selected_num[m]
        s=training_set[k]
        selected_data.append(s)

    for i in range(0,number_of_centre):
        for j in range(i,number_of_centre):
            distance=list(map(lambda x: x[0] - x[1], zip(selected_data[i], selected_data[j])))
            distance1 = []
            dislen=len(distance)

            for m in range(0,dislen):
                distance1.append(distance[m]** 2)
            dis1len = len(distance1)
            for n in range(0,dis1len):
                distance2 = distance2 + distance1[n]
            distance2 = distance2 ** 0.5
            if distance2>dmax:
                dmax=distance2
    sigma=(dmax/((2*number_of_centre)**0.5))

    return selected_data,sigma#、

#neuron function, input a center, sigma and x ,output result of one neuron, gaussian function is included
def Neuron(centre,sigma,x):
    distance = list(map(lambda x: x[0] - x[1], zip(x, centre)))
    distance1=[]
    distance2=0
    dislen=len(distance)
    for i in range(0,dislen):
        m=distance[i]**2
        distance1.append(m)
    dis1len=len(distance1)
    for j in range(0,dis1len):
        distance2=distance2+distance1[j]
    distance2=distance2**0.5
    di=distance2
    oi=GF(di,sigma)
    return oi


#calculate weight_matrix
def Get_Weight_Matrix(centre,sigma,x,label):
    xlen=len(x)
    centrelen=len(centre)
    weight_matrix=[[0 for j in range(0, centrelen+1)] for i in range(0, xlen)]
    for i in range(0,xlen):
        for j in range(0,centrelen):
            weight_matrix[i][j]=Neuron(centre[j],sigma,x[i])#this weight matrix is not true weight matrix, it is predict matrix
    for k in range(0,xlen):
        weight_matrix[k][centrelen]=1#and bias
    weight_matrix_zhuanzhi=(np.mat(weight_matrix)).T
    predict_matrx=weight_matrix
    #following code is to calculate real weight matrix
    weight_matrix=np.dot(np.dot(np.linalg.inv(np.dot(weight_matrix_zhuanzhi,weight_matrix)),weight_matrix_zhuanzhi),label)
    return predict_matrx,weight_matrix

#calculate accuracy_rate for method
def Accuracy_Rate(predict_label,real_label):
    pllen=len(predict_label)
    rllen=len(real_label)
    true_point=0
    for j in range(0,pllen):
        if predict_label[j]>0:
            predict_label[j]=1
        else:
            predict_label[j]=-1

    for i in range(0,pllen):
        if predict_label[i]==real_label[i]:
            true_point=true_point+1
    accuracy_rate=(true_point/rllen)
    return accuracy_rate


def Predict(predict_matrix,weight_matrix):
    predict_label=np.dot(predict_matrix,weight_matrix)
    return predict_label
def Train(dataset,labelset,num_centre):
    centre, sigma = Centre_Random_Selection(dataset, num_centre)
    predict_matrx, weight_matrix = Get_Weight_Matrix(centre, sigma, dataset, labelset)
    weight_matrix = (np.mat(weight_matrix)).T
    predict_label = Predict(predict_matrx, weight_matrix)
    accuracy_rate = Accuracy_Rate(predict_label, labelset)




    return accuracy_rate
def Predict_1(dataset,labelset,num_centre,testset):
    centre, sigma = Centre_Random_Selection(dataset, num_centre)
    predict_matrx, weight_matrix = Get_Weight_Matrix(centre, sigma, dataset, labelset)
    weight_matrix = (np.mat(weight_matrix)).T
    predict_label = Predict(predict_matrx, weight_matrix)
    accuracy_rate = Accuracy_Rate(predict_label, labelset)
    print(accuracy_rate)
    predict_matrx1=Predict_matrix(centre,sigma,testset)
    predict_label = Predict(predict_matrx1, weight_matrix)
    return predict_label


#want to predict something without label, should calculate predict matrix(output of sum of every neuron)
def Predict_matrix(centre,sigma,x):
    xlen = len(x)
    centrelen = len(centre)
    weight_matrix = [[0 for j in range(0, centrelen + 1)] for i in range(0, xlen)]
    for i in range(0, xlen):
        for j in range(0, centrelen):
            weight_matrix[i][j] = Neuron(centre[j], sigma, x[i])
    for k in range(0, xlen):
        weight_matrix[k][centrelen] = 1
    predict_matrx = weight_matrix
    return predict_matrx

h=[]
k=[]

#find out moset suitable number of centers
for j in range(2,100):

    h=[]
    for m in range(0,20):
        print(j,m)
        x=Train(dataset,labelset,j)
        h.append(x)
    k.append(np.mean(h))
print(k)

#calculate time
time_start=time.time()

a=Predict_1(dataset,labelset,30,testset)
time_end=time.time()
print('time cost',time_end-time_start,'s')


#out put result of test set, if predict number bigger than 0, it will classified to 1, if smaller than 0,will classified to -1
alen=len(a)
b=[]
for i in range(0,alen):
    if a[i]>=0:
        b.append(1)
    elif a[i]<0:
        b.append(-1)
print(b)



