


from sklearn import svm
import pylab as pl  # 绘图功能
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
# 使用管道将StandardScaler和SVC连在一起
import random
from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
from matplotlib import cm

from sklearn.pipeline import Pipeline
'''
This py document is to find a suitable Gamma and C,
main skeleton is to random select a group of test set and train set, and circulate try Gamma and C, 
    if a group of gamma and C can get best accuracy rate, then we can use this gamma and C
'''




'''
This part of code(line 33 to line 39) is to get data
'''
df = pd.read_csv('dataset1.csv', header=None)
data = []
for i in df.index:
    data.append(list(df.values[i]))
dataset = data#get data as dataset
labelset = pd.read_csv('labelset.csv')
labelset = labelset['label']#get label as labelset




'''
this function is to get training set and test set
     main thinking is we want that training set contains 70% of total data and test set has 30% of total data
'''
def train_and_test_set(dataset, labelset, num_train):#input datset ,labelset and how many data we want to put into training set
    whole_len = len(dataset)
    whole_len = whole_len - 1
    test_data_num = []
    train_data_num = []
    test_data = []
    train_data = []
    test_label = []
    train_label = []

    flag = 0
    while (flag != num_train):#get number from 0 to 330 randomly
        h = random.randint(0, whole_len)
        if train_data_num.count(h) == 0:
            train_data_num.append(h)
            flag = flag + 1
    for i in range(0, whole_len):
        if train_data_num.count(i) == 0:
            test_data_num.append(i)
        else:
            continue
    for j in range(0, whole_len):# save label
        if test_data_num.count(j) != 0:
            test_data.append(dataset[j])
            test_label.append(labelset[j])
        elif train_data_num.count(j) != 0:
            train_data.append(dataset[j])
            train_label.append(labelset[j])
        else:
            print("error happened, because:jst of dataset don't belong train or test dataset")
    return train_data, test_data, train_label, test_label, train_data_num, test_data_num


'''
this function is to define a accuracy function to illustrate the accuracy rate of this system
'''
def Predict(predict_set, predict_true_label):
    accurate_num = 0
    predict_label = clf.predict(predict_set)
    set_len = len(predict_set)
    for i in range(0, set_len):
        if predict_label[i] == predict_true_label[i]:
            accurate_num = accurate_num + 1
        else:
            continue
    accurate_percentage = (accurate_num / set_len)
    return accurate_percentage, predict_label

gamma=[]
C=[]
step=0.05
for u in range(1,100):
    current_number=u*step
    gamma.append(current_number)
    C.append(current_number)


#contain best accurate, training set, test set, gamma and C
best_accurate=0
best_train_data_num=[]
best_test_data_num=[]
best_gamma=0
best_C=0
s=0
jincheng=0


#get training test set information
train_data, test_data, train_label, test_label ,train_data_num,test_data_num= train_and_test_set(dataset, labelset, num_train=231)
for h in gamma:#circulate try gamma and C
    for g in C:
        jincheng=jincheng+1
        print('Progress:',jincheng,'/',)
        clf = svm.SVC(kernel='rbf',gamma=h,C=g) #define the svm, kernel is rbf and gamma equals to h, C equals to g
        # 训练分类器
        clf.fit(train_data, train_label)  # 调用分类器的 fit 函数建立模型（即计算出划分超平面，且所有相关属性都保存在了分类器 cls 里）#fit the svm
        accurate_percentage, predict_label = Predict(test_data, test_label)
        if accurate_percentage >= best_accurate:#refresh the best gamma and C
            best_accurate = accurate_percentage
            best_gamma=h
            best_C =g
        else:
            continue
print('Best Accurate is：',best_accurate)#print the best accuracy rate under best gamma and best C
print('Best gamma is:',best_gamma)#0.1
print('Best C is:',best_C)#1.2




