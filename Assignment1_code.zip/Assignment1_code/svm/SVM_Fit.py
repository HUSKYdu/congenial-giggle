from sklearn import svm
import pylab as pl  # 绘图功能
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import pandas as pd
import random
import numpy as np
import time

#time_start=time.time()
#time_end=time.time()
#print('time cost',time_end-time_start,'s')
'''
similar with SVM_Find_best-GAMMA_C.py 

but we believe that the accuracy of SVM also will be influence by the selection of training set and test set 
    so we define this python document to find the best training set and test set  
'''


from sklearn.pipeline import Pipeline

df = pd.read_csv('dataset1.csv', header=None)  # 因为没有表头，不把第一行作为每一列的索引
data = []
for i in df.index:
    data.append(list(df.values[i]))
dataset = data
labelset = pd.read_csv('labelset.csv')
labelset = labelset['label']


hk = pd.read_csv('testset.csv', header=None)  # 因为没有表头，不把第一行作为每一列的索引
test = []
for i in hk.index:
    test.append(list(hk.values[i]))
testset = test

#slelect training and test set information
def train_and_test_set(dataset, labelset, num_train):
    whole_len = len(dataset)
    whole_len = whole_len - 1
    test_data_num = []
    train_data_num = []
    test_data = []
    train_data = []
    test_label = []
    train_label = []

    flag = 0
    while (flag != num_train):
        h = random.randint(0, whole_len)
        if train_data_num.count(h) == 0:
            train_data_num.append(h)
            flag = flag + 1
    for i in range(0, whole_len):
        if train_data_num.count(i) == 0:
            test_data_num.append(i)
        else:
            continue
    for j in range(0, whole_len):
        if test_data_num.count(j) != 0:
            test_data.append(dataset[j])
            test_label.append(labelset[j])
        elif train_data_num.count(j) != 0:
            train_data.append(dataset[j])
            train_label.append(labelset[j])
        else:
            print("error happened, because:jst of dataset don't belong train or test dataset")
    return train_data, test_data, train_label, test_label, train_data_num, test_data_num


def Predict(predict_set, predict_true_label):
    accurate_num = 0
    predict_label = clf.predict(predict_set)
    set_len = len(predict_set)
    for i in range(0, set_len):
        if predict_label[i] == predict_true_label[i]:
            accurate_num = accurate_num + 1
        else:
            continue
    accurate_percentage = (accurate_num / set_len)
    return accurate_percentage, predict_label

best_accurate=0
best_train_data_num=[]
best_test_data_num=[]
s=0
jincheng=0



'''
different in this part, we circulate to select training set 1000 times, 
       and we save the best training set and test set selection in best_train_data_num[] and best_test_data_num[]
'''
best_train_data=[]
best_test_data=[]



clf = svm.SVC(kernel='rbf',gamma=0.35,C=4.95)  # .SVC（）就是 SVM 的方程，参数 kernel 为线性核函数
     # 训练分类器
clf.fit(dataset, labelset)  # 调用分类器的 fit 函数建立模型（即计算出划分超平面，且所有相关属性都保存在了分类器 cls 里）
      # 打印分类器 clf 的一系列参数
print('^^^^^^^^^^^^^^^^^^^^^')
result=clf.predict(testset)
print(result)
print(testset)


accurate=[]
for i in range(0,1000):
    print('Progress:',i,'1000')
    time_start = time.time()
    train_data, test_data, train_label, test_label, train_data_num, test_data_num = train_and_test_set(dataset,
                                                                                                       labelset,
                                                                                                       num_train=231)
    clf = svm.SVC(kernel='rbf', gamma=0.35, C=4.95) #gamma and C is selected on SVM_Find_best_gamma_C.py


    #fit SVM
    clf.fit(train_data, train_label)

    accurate_percentage, predict_label = Predict(test_data, test_label)
    accurate.append(accurate_percentage)
    time_end = time.time()
    print('time cost', time_end - time_start, 's')
print(accurate)
print('median of accurate is:',np.median(accurate))
print('mean of accurate is:',np.mean(accurate))
print('max of accurate is:',np.max(accurate))
print('min of accurate is:',np.min(accurate))
plt.hist(accurate, bins=10)
plt.title('Histogram of Accuracy Rate in SVM')
plt.xlabel('Accuracy Rate')
plt.xlabel('Number of Point')
plt.savefig('histogram.svg')
plt.show()


